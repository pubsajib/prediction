<?php 
class tournamentTop {
	public static function render($attr) {
		$defaults = [
			'tournament' => 0, 
			'number' => 10, 
			'avatar' => 0, 
			'excerpt-avatar' => 0, 
			'bpl-accuracy' => 0, 
			'bbl-accuracy' => 0, 
			'smash-accuracy' => 0, 
			'info' => 0, 
			'class'=>'predictorListWrapper'
		];
		$attr = shortcode_atts($defaults, $attr, 'tournamentTop');
		$html  = '';
		$predictors = self::getPredictorsList();
		$ranking = self::getRakingForTournament('all', $attr['tournament'], $predictors, 1, 0);
		//$html  .= help($ranking['all'], false);
		$html .= self::html($predictors, $ranking, $attr);
		return $html;
	}
	public static function html($predictors, $ranking, $attr) {
		$html = '';
		if ($ranking['all']) {
			$html .= '<div class="'. $attr['class'] .'">';
			foreach ($ranking['all'] as $rankID => $rank) {
				if ($rankID >= $attr['number']) break;
				$user = $predictors[$rank['id']];
				$rank = userRankingStatusFor($user->ID, $ranking);
				$profileLink = site_url('predictor/?p='. $user->user_login);
				//Excerpt 				
				$html .= '<div class="excerpt-top">';
					if ($attr['excerpt-avatar']) {
						$ratingIcon = $rank['num'] ? '<p>'. $rank['num'] .'</p>' : '';
						$html .= '<div class="author-photo"> <a href="'. site_url('predictor/?p='. $user->user_login) .'">'. get_avatar( $user->user_email , '60 ') .'</a></div>';
						$html .= '<h3><a href="'. site_url('predictor/?p='. $user->user_login) .'">'. get_the_author_meta('nickname',$user->ID) .'</a></h3>';
					}
					// BPL Accuracy					
					if ($attr['bpl-accuracy']) {
						$bpl = tournamentData($user->ID, 279);
						if (!empty($bpl['avg'])) {
							if (!empty($bpl['avg'])) {   
									$html .= "<h4>" . $bpl['avg']['all']['rate'] . "%</h4>";
							}
						}
					}
					//BBL Accuracy 
					if ($attr['bbl-accuracy']) {
						$bbl = tournamentData($user->ID, 270);
						if (!empty($bbl['avg'])) {
							if (!empty($bbl['avg'])) {   
									$html .= "<h4>" . $bbl['avg']['all']['rate'] . "%</h4>";
							}
						}
					}	
					//Super Smash 
					if ($attr['smash-accuracy']) {
						$smash = tournamentData($user->ID, 276);
						if (!empty($smash['avg'])) {
							if (!empty($smash['avg'])) {   
									$html .= "<h4>" . $smash['avg']['all']['rate'] . "%</h4>";
							}
						}
					}	
					
				$html .= '</div>';
				// $html .= '<div id="predictor_'. $user->ID .'" class="predictorContainer author-profile-card'. $rank['class'] .'">';
		    		// PROFILE INFORMATION
					$html .= '<div class="profile-info">';
						if ($attr['avatar']) {
							$ratingIcon = $rank['num'] ? '<p>'. $rank['num'] .'</p>' : '';
							$html .= '<div class="author-photo"> '. get_avatar( $user->user_email , '60 ') .'</div>';
							$html .= '<h3><a href="'. site_url('predictor/?p='. $user->user_login) .'">'. get_the_author_meta('nickname',$user->ID) .'</a></h3>';
						}
						if ($attr['info']) {
					        $html .= '<p>';
					            if ($user->user_url) $html .= '<strong>Website:</strong> <a href="'. $user->user_url .'">'. $user->user_url .'</a><br />';
					            if ($user->user_description) $html .= $user->user_description;
					        $html .= '</p>';
						}
					$html .= '</div>';
				// $html .= '</div>';
			}
			$html .= '</div>';
		}
		return $html;
	}
	public static function getRakingForTournament($ratingType='all', $tournamentID=false, $predictors='', $minItemToPredict=5, $itemGrace=0, $minParticipationRate=10, $minRate=10) {
		$top3 = 3;
		$top10 = 10;
		$ranking = [];
		$users = [];
		$rankedUsers = ['top3'=>[], 'top10'=>[]];
		$minParticipationWithGrace = $minItemToPredict - $itemGrace;
		// RANKING FOR ALL USERS
		if (!$predictors) $predictors = get_users('role=predictor');
		if ($predictors) {
			foreach ($predictors as $predictor) {
				// LIFE TIME DATA
				if ($tournamentID) $prediction = tournamentData($predictor->ID, $tournamentID);
				else $prediction = predictionsOf($predictor->ID);
				// help($prediction['avg']['all']);
				$isRankAble = false;
				if (!empty($prediction['avg'])) {
					$PRType = $prediction['avg'][$ratingType]['participated'];
					$PMatch = $prediction['avg']['match']['participated'];
					$score = $prediction['avg'][$ratingType]['rate'];
					$criterias = [
						'UID'=>$predictor->ID, 
						'participated' => $PRType, 
						'minItem' => $minItemToPredict, 
						'minParticipation' => $minParticipationRate, 
						'rate' => $score,
						'minRate' => $minRate,
					];
					if ($PRType) $isRankAble = isValidForRankingForTournament($criterias);
					$ranking[$predictor->ID]['id'] = $predictor->ID;
					$ranking[$predictor->ID]['eligible'] = $isRankAble;
					$ranking[$predictor->ID]['score'] = $score;
					$ranking[$predictor->ID]['participated'] = $PRType;
					$ranking[$predictor->ID]['p_match'] = $PMatch;

					$eligible[] = $isRankAble;
					$scoreData[] = $score;
					$PRTypeData[] = $PRType;
					$participatedData[] = $PMatch;
					$matchData[] = $PMatch;
				} else {
					$PRType = 0;
					$PMatch = 0;
					$score = 0;
					$ranking[$predictor->ID]['id'] = $predictor->ID;
					$ranking[$predictor->ID]['eligible'] = 0;
					$ranking[$predictor->ID]['score'] = $score;
					$ranking[$predictor->ID]['participated'] = $PRType;
					$ranking[$predictor->ID]['p_match'] = $PMatch;

					$eligible[] = -100;
					$scoreData[] = $score;
					$PRTypeData[] = $PRType;
					$matchData[] = $PMatch;
				}
				$users[$predictor->ID] = $predictor->data;
			}
			// TEST DATA
			// $ranking[3]['id'] = 3;
			// $ranking[3]['score'] = 8235;
			// $ranking[3]['participated'] = 17;
			// $ranking[3]['match'] = 16;
			// $scoreData[] = 8235;
			// $PRType[] = 17;
			// $matchData[] = 16;
			if (isset($scoreData) || isset($PRType) || isset($matchData)) {
				array_multisort($eligible, SORT_DESC, $scoreData, SORT_DESC, $PRTypeData, SORT_DESC, $matchData, SORT_DESC, $ranking);
			}
		}
		// 	PREDICTORS BY RANK
		if ($ranking) {
			$counter = 1;
			$rankingCount = count($ranking);
			if ($top3 > $rankingCount) $top3 = $rankingCount;
			if ($top10 > $rankingCount) $top10 = $rankingCount;
			foreach ($ranking as $userID => $rank) {
				if ($counter > $top10) break;
				if ($rank['participated'] >= $minParticipationWithGrace ) {
					if ($counter <= $top3) $rankedUsers['top3'][] = $rank['id'];
					$rankedUsers['top10'][] = $rank['id'];
				}
				// if ($counter <= $top3) $rankedUsers['top3'][$userID] = $users[$userID];
				// $rankedUsers['top10'][$userID] = $users[$userID];
				$counter++;
			}
		}
		$rankedUsers['all'] = $ranking;
			// help($rankedUsers);
		return $rankedUsers;
	}
	public static function getPredictorsList() {
		$users = [];
		$predictors = get_users( 'role=predictor' );
		if ($predictors) {
			foreach ($predictors as $predictor) {
				$users[$predictor->ID] = $predictor;
			}
		}
		return $users;
	}
	public static function isValidForRanking($criterias) {
		$lifeTimeParticipationCriteria = $criterias['minLifetimeParticipationRate'] > $criterias['lifeTimePublishedEventRate'];
		if ($criterias['participated'] < 10) return 10;
		else if ($criterias['participated'] < 20) return 20;
		else if ($criterias['participated'] < 30) return 30;
		else if ($criterias['participated'] < 40) return 40;
		else if ($criterias['participated'] < 50) return 50;
		else if ($criterias['participated'] < 60) return 60;
		else if ($criterias['participated'] < 70) return 70;
		else if ($criterias['accuracy'] < 50) return 80;

		// ACTUAL RANKING BEGAIN
		else if ($criterias['grace'] > $criterias['participated']) return 85;
		else if ($lifeTimeParticipationCriteria) {
			// if ($criterias['participated'] < 80) return 95;
			return 90;
		}
		else return 100;
	}
 }
add_shortcode('tournamentTop', ['tournamentTop', 'render']);