<?php 
class tossTop {
	public static function render($attr) {
		$defaults = [
			'number' => 30, 
			'avatar' => 1, 
			'info' => 0, 
			'session-accuracy' => 0, 
			'accuracy' => 0, 
			'league-accuracy' => 0, 
			'win-loss' => 0, 
			'class' => 'predictorListWrapper excerpt'
		];
		$attr = shortcode_atts($defaults, $attr, 'tossTop');
		$html  = '';
		$predictors = self::getPredictorsList();
		$ranking = self::getRakingFor('toss', false, $predictors);
		// $html .= help($ranking, false);
		$html .= self::html($predictors, $ranking, $attr);
		return $html;
	}
	public static function html($predictors, $ranking, $attr) {
		$html = '';
		if ($ranking['all']) {
			$html = '';
			$html .= '<div class="predictorListWrapper"><div class="equalAll">';
			foreach ($ranking['all'] as $rank) {
				$user = $predictors[$rank['id']];
				$ratingIcon = '';
				$rank = userRankingStatusFor($user->ID, $ranking);
				if ($rank['num']) $ratingIcon = '<p>'. $rank['num'] .'</p>';
				$profileLink = site_url('predictor/?p='. $user->user_login);
				$html .= '<div id="predictor_'. $user->ID .'" class="predictorContainer author-profile-card'. $rank['class'] .'">';
					// USER'S ALL PREDICTIONS
		    		$UP = predictionsOf($user->ID);
		                        if (!empty($UP['avg'])) {
		                            $html .= '<table class="table top-accuracy">';
		                                $html .= '<tr>';
											$html .= '<td><small>Accuracy (' . $UP['avg']['all']['participated'] . ') </small><br>' . $UP['avg']['all']['rate'] . '%<br><small class="last"><span class="green">'. $UP['avg']['all']['correct'] . '</span>/<span class="red">'. $UP['avg']['all']['incorrect'] . '</span></small></td>';
		                                    
		                                    $html .= '<td><small>Match (' . $UP['avg']['match']['participated'] . ') </small><br>' . $UP['avg']['match']['rate'] . '%<br><small class="last"><span class="green">'. $UP['avg']['match']['correct'] . '</span>/<span class="red">'. $UP['avg']['match']['incorrect'] . '</span></small></td>';
		                                    $html .= '<td><small>Toss (' . $UP['avg']['toss']['participated'] . ')</small><br>' . $UP['avg']['toss']['rate'] . '%<br><small class="last"><span class="green">'. $UP['avg']['toss']['correct'] . '</span>/<span class="red">'. $UP['avg']['toss']['incorrect'] . '</span></small></td>';
		                                $html .= '</tr>';
		                            $html .= '</table>';
		                        }
		    		// PROFILE INFORMATION
					$html .= '<div class="profile-info">';
						$html .= profileInfo($user, false, $ratingIcon);
					$html .= '</div>';
					// USER'S TOURNAMENT BASIS PREDICTIONS
					$html .= '<div class="sliderFooter">';
						$html .= '<table class="table">';
						$html .= '<tr>';
						$html .= '<th>League</th>';
						$html .= '<th>Accuracy</th>';
						$html .= '<th>Match</th>';
						$html .= '<th>Toss</th>';
						$html .= '</tr>';
						$html .= '<tr>';
						$data = tournamentData($user->ID, 270);
						if (isset($data['avg'])) {
							$html .= "<td>BBL</td>";
							$html .= "<td>" . round($data['avg']['all']['rate']) . "%</td>";
							$html .= "<td>" . round($data['avg']['match']['rate']) . "% (" . $data['avg']['match']['participated'] . ")</td>";
							$html .= "<td>" . round($data['avg']['toss']['rate']) . "% (" . $data['avg']['toss']['participated'] . ")</td>";
							$html .= '</tr>';
						}
						$data = tournamentData($user->ID, 276);
						if (isset($data['avg'])) {
							$html .= "<td>Smash</td>";
							$html .= "<td>" . round($data['avg']['all']['rate']) . "%</td>";
							$html .= "<td>" . round($data['avg']['match']['rate']) . "% (" . $data['avg']['match']['participated'] . ")</td>";
							$html .= "<td>" . round($data['avg']['toss']['rate']) . "% (" . $data['avg']['toss']['participated'] . ")</td>";
							$html .= '</tr>';
						}
						$data = tournamentData($user->ID, 279);
						if (isset($data['avg'])) {
							$html .= "<td>BPL</td>";
							$html .= "<td>" . round($data['avg']['all']['rate']) . "%</td>";
							$html .= "<td>" . round($data['avg']['match']['rate']) . "% (" . $data['avg']['match']['participated'] . ")</td>";
							$html .= "<td>" . round($data['avg']['toss']['rate']) . "% (" . $data['avg']['toss']['participated'] . ")</td>";
							$html .= '</tr>';
						}
						$data = tournamentData($user->ID, 272);
						if (isset($data['avg'])) {
							$html .= "<td>WBBL</td>";
							$html .= "<td>" . round($data['avg']['all']['rate']) . "%</td>";
							$html .= "<td>" . round($data['avg']['match']['rate']) . "% (" . $data['avg']['match']['participated'] . ")</td>";
							$html .= "<td>" . round($data['avg']['toss']['rate']) . "% (" . $data['avg']['toss']['participated'] . ")</td>";
							$html .= '</tr>';
						}
						$html .= '</table>';
						$html .= '</div>';
						$html .= '<div class="profile-link">';
						$html .= '<a href="'. site_url('predictor/?p='. $user->user_login) .'" target="_blank">VIEW PROFILE</a>';
						$html .= '</div>';

				$html .= '</div>';
			}
			$html .= '</div></div>';
		}
		return $html;
	}
	public static function getRakingFor($ratingType='match', $tournamentID=false, $predictors='', $minItemToPredict=80, $itemGrace=10, $minParticipationRate=40) {
		$top3 = 3;
		$top10 = 10;
		$ranking = [];
		$users = [];
		$rankedUsers = ['top3'=>[], 'top10'=>[]];
		$minParticipationWithGrace = $minItemToPredict - $itemGrace;
		// RANKING FOR ALL USERS
		if (!$predictors) $predictors = get_users('role=predictor');
		if ($predictors) {
			foreach ($predictors as $predictor) {
				// LIFE TIME DATA
				if ($tournamentID) $prediction = tournamentData($predictor->ID, $tournamentID);
				else $prediction = predictionsOf($predictor->ID);
				// help($prediction['avg']['all']);
				$isRankAble = false;
				if (!empty($prediction['avg'])) {
					$participated = $prediction['avg']['all']['participated'];
					$score = $prediction['avg']['all']['rate'];
					$rscore = $prediction['avg'][$ratingType]['rate'];
					$rparticipated = $prediction['avg'][$ratingType]['participated'];
					
					$criterias = [
						'UID'=>$predictor->ID, 
						'participated' => $participated,
						'minLifetimeParticipationRate' => $minParticipationRate, 
						'accuracy' => $score,
						'grace' => $minParticipationWithGrace,
					];
					$lifeTimeEvents = count(lifeTimePublished($criterias['UID']));
					if ($lifeTimeEvents) {
						$criterias['lifeTimePublishedEvents'] = $lifeTimeEvents;
						$criterias['lifeTimePublishedEventRate']  = number_format(($criterias['participated'] / $lifeTimeEvents) * 100, 2);
					} else {
						$criterias['lifeTimePublishedEvents'] = 0;
						$criterias['lifeTimePublishedEventRate'] = 0;
					}
					if ($participated) $isRankAble = self::isValidForRanking($criterias);
					$ranking[$predictor->ID]['id'] = $predictor->ID;
					$ranking[$predictor->ID]['eligible'] = $isRankAble;
					$ranking[$predictor->ID]['rscore'] = $rscore;
					$ranking[$predictor->ID]['rparticipated'] = $rparticipated;
					$ranking[$predictor->ID]['lifeTimePublishedEvents'] = $criterias['lifeTimePublishedEvents'];
					$ranking[$predictor->ID]['lifeTimePublishedEventRate'] = $criterias['lifeTimePublishedEventRate'];
					$ranking[$predictor->ID]['minLifetimeParticipationRate'] = $criterias['minLifetimeParticipationRate'];
					$ranking[$predictor->ID]['score'] = $score;
					$ranking[$predictor->ID]['participated'] = $participated;

					$eligible_sort[] = $isRankAble;
					$accuracy_sort[] = $rscore;
					$totalParticipated_sort[] = $rparticipated;
				} else {
					$rscore = 0;
					$rparticipated = 0;
					$ranking[$predictor->ID]['id'] = $predictor->ID;
					$ranking[$predictor->ID]['eligible'] = 0;
					$ranking[$predictor->ID]['rscore'] = $rscore;
					$ranking[$predictor->ID]['rparticipated'] = $rparticipated;
					$ranking[$predictor->ID]['lifeTimePublishedEvents'] = 0;
					$ranking[$predictor->ID]['lifeTimePublishedEventRate'] = 0;
					$ranking[$predictor->ID]['minLifetimeParticipationRate'] = 0;
					$ranking[$predictor->ID]['score'] = 0;
					$ranking[$predictor->ID]['participated'] = 0;

					$eligible_sort[] = -9999;
					$accuracy_sort[] = $rscore;
					$totalParticipated_sort[] = $rparticipated;
				}
				$users[$predictor->ID] = $predictor->data;
			}
			// TEST DATA
			// $ranking[3]['id'] = 3;
			// $ranking[3]['score'] = 8235;
			// $ranking[3]['participated'] = 17;
			// $ranking[3]['match'] = 16;
			// $scoreData[] = 8235;
			// $PRType[] = 17;
			// $matchParticipated[] = 16;
			if (isset($eligible_sort) || isset($accuracy_sort) || isset($totalParticipated_sort)) {
				array_multisort(
					$eligible_sort, SORT_DESC, 
					$accuracy_sort, SORT_DESC,
					$totalParticipated_sort, SORT_DESC,  
					$ranking
				);
			}
		}
		// 	PREDICTORS BY RANK
		if ($ranking) {
			$counter = 1;
			$rankingCount = count($ranking);
			if ($top3 > $rankingCount) $top3 = $rankingCount;
			if ($top10 > $rankingCount) $top10 = $rankingCount;
			foreach ($ranking as $userID => $rank) {
				if ($rank['eligible'] >= 95) {
					if ($counter > $top10) break;
					if ($rank['participated'] >= $minParticipationWithGrace ) {
						if ($counter <= $top3) $rankedUsers['top3'][] = $rank['id'];
						$rankedUsers['top10'][] = $rank['id'];
					}
					// if ($counter <= $top3) $rankedUsers['top3'][$userID] = $users[$userID];
					// $rankedUsers['top10'][$userID] = $users[$userID];
					$counter++;
				}
			}
		}
		$rankedUsers['all'] = $ranking;
		// help($rankedUsers);
		return $rankedUsers;
	}
	public static function getPredictorsList() {
		$users = [];
		$predictors = get_users( 'role=predictor' );
		if ($predictors) {
			foreach ($predictors as $predictor) {
				$users[$predictor->ID] = $predictor;
			}
		}
		return $users;
	}
	public static function isValidForRanking($criterias) {
		$lifeTimeParticipationCriteria = $criterias['minLifetimeParticipationRate'] > $criterias['lifeTimePublishedEventRate'];
		if ($criterias['participated'] < 10) return 10;
		else if ($criterias['participated'] < 20) return 20;
		else if ($criterias['participated'] < 30) return 30;
		else if ($criterias['participated'] < 40) return 40;
		else if ($criterias['participated'] < 50) return 50;
		else if ($criterias['participated'] < 60) return 60;
		else if ($criterias['participated'] < 70) return 70;
		else if ($criterias['accuracy'] < 50) return 80;

		// ACTUAL RANKING BEGAIN
		else if ($criterias['grace'] > $criterias['participated']) return 85;
		else if ($lifeTimeParticipationCriteria) {
			// if ($criterias['participated'] < 80) return 95;
			return 90;
		}
		else return 100;
	}
 }
add_shortcode('tossTop', ['tossTop', 'render']);