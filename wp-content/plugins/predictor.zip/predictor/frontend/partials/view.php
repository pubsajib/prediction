<div id="modal-custom" data-iziModal-group="grupo1">
    <button data-iziModal-close class="icon-close">x</button>
    <section>
    	<div class="pLoginMessage"></div>
        <input id="p_user" type="text" placeholder="Username">
        <input id="P_pass" type="password" placeholder="Password">
        <footer>
            <button data-iziModal-close>Cancel</button>
            <button type="submit" class="submit">Log in</button>
        </footer>
    </section>
</div>