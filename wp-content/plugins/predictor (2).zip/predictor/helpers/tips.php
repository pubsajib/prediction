<?php 
function getTipsHTMLFor($eventID, $postsPerPage=2) {
	$tips = new Tips($eventID, $postsPerPage);
	echo $tips->getTipsHTML();
	return false;
}
/**
 * Tips
 */
class Tips{
	private $eventID = 0;
	private $pp = 0;
	function __construct($eventID, $pp) {
		$this->eventID = $eventID;
		$this->pp = $pp;
		return $this->getTipsHTML();
	}
	function getTipsHTML() {
		$html 	= '';
		$data 	= $this->getTips();
		$tips 	= !empty($data['tips']) ? $data['tips'] : false;
		$users 	= !empty($data['users']) ? $data['users'] : false;
		if ($tips) {
			$total = count($tips);
			$html .= '<div class="tips-wrapper" style="border:1px solid red;padding: 50px 100px">';
				$html .= $this->getUserFilter($users);
		        $html .= '<div class="tips-container">';
		        	foreach ($tips as $tipSI => $tip) {
		        		$tipNumber = $tipSI + 1;
		        		$isActive = $tipNumber <= $this->pp ? ' active' : '';
			            $html .= '<div style="border:1px solid red;" id="tips_'. $tipNumber .'" class="tips '. $isActive.'" user='.$tip['userID'].' time='.$tip['time'].'>';
			                $html .= '<div class="heading">';
			                    $html .= '<p class="left"><span class="name">'.$tip['name'].',</span> '.$tip['date'] .'</p>';
			                    // $html .= '<p class="right"><span class="love likeDislikeBtn" even='.$this->eventID.' user='.$tip['userID'].' index='.$tipSI.'>&#10084;</span> <span class="l-count">100</span></p>';
			                $html .= '</div>';
			                $html .= '<div class="message">'. $tip['tip'] .'</div>';
			            $html .= '</div>';
		        	}
		        $html .= '</div>';
		        $html .= '<div class="tips-loader-container"></div>';
		        if ($total > $this->pp) {
    		        $html .= '<div class="laodmore">';
    		            $html .= '<a href="javascript;" class="btn block showMoreTipsBtn" items='. $this->pp .' pp='. $this->pp .' total='. $total .'>View More Tips</a>';
    		        $html .= '</div>';
		        }
		    $html .= '</div>';
		}
	    return $html;
	}
	function getTips() {
		$tipsArr = ['tips'=>[], 'users'=>[]];
		$tipsCounter = 0;
		$allTips = (array) get_post_meta($this->eventID, 'event_tips', true);
		if ($allTips && is_array($allTips)) {
			foreach ($allTips as $uID => $userTips) {
				if ($userTips) {
					foreach ($userTips as $tip) {
						$tip = explode('##T##', $tip);
						$date 	= !empty($tip[1]) ? '<span class="date">'. date('M d Y', $tip[1]) .'</span>' : '';
						$time 	= !empty($tip[1]) ? '<span class="time">'. date('M d Y', $tip[1]) .'</span>' : '';
						$dateTime = $date.' | '.$time;
						$tipsArr['tips'][$tipsCounter]['time'] 	 	= !empty($tip[1]) ? $tip[1] : 0;
						$tipsArr['tips'][$tipsCounter]['date'] 		= $dateTime;
						// $tipsArr['tips'][$tipsCounter]['userID'] 	= $uID;
						$tipsArr['tips'][$tipsCounter]['userID'] 	= rand(1,3);
						$tipsArr['tips'][$tipsCounter]['name'] 		= get_the_author_meta('nickname',$uID) ?: 'N/A';
						$tipsArr['tips'][$tipsCounter]['tip'] 	 	= $tip[0];
						// USER DATA
						$tipsArr['users'][$uID] = get_the_author_meta('nickname',$uID) ?: 'N/A';
						$tipsCounter++;
					}
				}
			}
		}
		return $tipsArr;
	}
	function getUserFilter($users) {
		$html = '';
		if ($users) {
			$html .= '<div class="input-group">';
				$html .= '<select class="custom-select" id="userFilter">';
					$html .= '<option value="">Choose...</option>';
					foreach ($users as $uID => $name) $html .= '<option value="'. $uID .'">'. $name .'</option>';
					$html .= '<option value="2">name 2</option>';
					$html .= '<option value="3">name 3</option>';
				$html .= '</select>';
				$html .= '<div class="input-group-append"><button class="btn tipsFilterBtn" type="button">Search</button></div>';
			$html .= '</div>';
		}
		return $html;
	}
	static function getAdminHTML($eventID) {
		$html = '';
		if ($allTips = (array) get_post_meta($eventID, 'event_tips', true)) {
        	foreach ($allTips as $uID => $userTips) {
		        if ($userTips && is_array($userTips)) {
		        	$userName = get_the_author_meta('nickname',$uID) ?: 'N/A';
		        	$html .= '<div class="tipsContainer">';
		        		$html .= '<h3 style="margin:0;color: #fff; ">'. $userName .'</h3>';
		        		foreach ($userTips as $tipSI => $tip) {
			        		$tip = explode('##T##', $tip);
			        		$tipMsg = !empty($tip[0]) ? $tip[0] : false;
			        		$tipTime = !empty($tip[1]) ? date('M d Y', $tip[1]) : false;
			        		if ($tipMsg && $tipTime) {
					            $html .= '<div class="tipItem">';
					                $html .= '<div class="heading">';
					                    $html .= '<p class="left"><span class="date">'.$tipTime.'</span> </p>';
					                    $html .= '<button type="button" class="button button-primary button-small removeTip" event='. $eventID .' user='. $uID .' index='. $tipSI .'>Delete</span>';
					                $html .= '</div>';
					                $html .= '<div class="message">'. $tipMsg .'</div>';
					            $html .= '</div>';
			        		}
		        		}
		        	$html .= '</div>';
		        }
	        }
	        $html .= '<div class="tips-loader-container"></div>';
		}
		return $html;
	}
}
?>
