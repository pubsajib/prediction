(function ($) {
  'use strict';

  /**
   * Prints Hello world! to the console
   */
  var helloWorld = function () {
    // console.log('Hello world!');
  };
  var pNotify = function () {
    var fx = "wobble", //wobble shake
        $modal = $(this).closest('.iziModal');

    if (!$modal.hasClass(fx)) {
        $modal.addClass(fx);
        setTimeout(function() {
            $modal.removeClass(fx);
        }, 1500);
    }
    }

  $(document).ready(function () {
    helloWorld();
    /* Instantiating iziModal */
    $("#modal-custom").iziModal({
        overlayClose: false,
        overlayColor: 'rgba(0, 0, 0, 0.6)'
    });

    $(document).on('click', '.custom-login', function (event) {
        event.preventDefault();
        $('#modal-custom').iziModal('open');
    });

    /* JS inside the modal */

    $("#modal-custom").on('click', 'header a', function(event) {
        event.preventDefault();
        var index = $(this).index();
        $(this).addClass('active').siblings('a').removeClass('active');
        $(this).parents("div").find("section").eq(index).removeClass('hide').siblings('section').addClass('hide');

        if ($(this).index() === 0) {
            $("#modal-custom .iziModal-content .icon-close").css('background', '#ddd');
        } else {
            $("#modal-custom .iziModal-content .icon-close").attr('style', '');
        }
    });

    $("#modal-custom").on('click', '.submit', function(event) {
        event.preventDefault();
        var email = jQuery('#p_user').val()
        var pass = jQuery('#P_pass').val()
        var remember = jQuery('#remember').is(':checked')

        if (email != '' && pass != ''){
            jQuery.ajax({
                type: 'POST',
                url: object.ajaxurl + '?action=user_login',
                cache: false,
                data: {
                    email: email,
                    pass: pass,
                    remember: remember,
                    security: object.ajax_nonce
                },
                success: function(response, status, xhr) {
                    if (response == true) {
                        window.location.reload()
                    } else {
                        $('.pLoginMessage').html('<p> Invalid credentials </p>');
                        var fx = "wobble", //wobble shake
                            $modal = $(this).closest('.iziModal');

                        if (!$modal.hasClass(fx)) {
                            $modal.addClass(fx);
                            setTimeout(function() {
                                $modal.removeClass(fx);
                            }, 1500);
                        }
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
        } else {
            var fx = "wobble", //wobble shake
                $modal = $(this).closest('.iziModal');

            if (!$modal.hasClass(fx)) {
                $modal.addClass(fx);
                setTimeout(function() {
                    $modal.removeClass(fx);
                }, 1500);
            }
        }
    });

  });

})(jQuery);
