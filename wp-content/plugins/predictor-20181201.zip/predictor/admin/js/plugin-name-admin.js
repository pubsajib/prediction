(function ($) {
  'use strict';

})(jQuery);
