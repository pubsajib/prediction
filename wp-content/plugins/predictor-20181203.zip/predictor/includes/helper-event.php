<?php 
function getEventIDs() {
    $query = array(
        'post_type' => 'event',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
    );
    $events = new WP_Query($query);
    // $events = $events->found_posts;
    $events = $events->posts;
    return $events;
}
function predictionFor($eventID, $userID) {
	$meta  = get_post_meta($eventID, 'event_ops', true);
	$ans   = get_post_meta($eventID, 'event_ans', true);
    $data = [];
    if (!$ans[$userID]) return false;
    if ($meta['teams']) {
        foreach ($meta['teams'] as $team) {
            $gain = 0;
            $ID = predictor_id_from_string($team['name']);
            $teamID = 'team_'. $ID;

            // OPTIONS
            if ($meta[$teamID]) {
                foreach ($meta[$teamID] as $option) {
                    $optionID = predictor_id_from_string($option['title']);
                    $defaultID = 'default_'. $ID .'_'. $optionID;
                    $defaultAns = $meta[$defaultID];

                    $answerID = $teamID .'_'. $optionID;
                    $givenAns = $ans[$userID][$answerID];

                    $default = getDefaultWeight($option['weight'], $defaultAns);
                    $data[$teamID][$answerID]['weight']     = $default;
                    $data[$teamID][$answerID]['default']    = $defaultAns;
                    $data[$teamID][$answerID]['given']      = $givenAns;
                    if ($defaultAns == $givenAns) {
                        $data[$teamID][$answerID]['is_correct'] = true;
                        $gain += $default;
                    } else{
                        $data[$teamID][$answerID]['is_correct'] = false;
                        $gain -= $default;
                    }
                    // echo '<br> default : '. $default .' === index: '. $default .' === givenAns: '. $givenAns;
                }
            }
            $data[$teamID]['gain'] = $gain;
        }

    }
    echo '<br><pre>'. print_r($data, true) .'</pre><hr>';
	echo '<br><pre>'. print_r($meta, true) .'</pre>';
	echo '<br><pre>'. print_r($ans, true) .'</pre>';
}
function getDefaultWeight($weights, $defaultAns) {
    if ($weights) {
        foreach ($weights as $weight) {
            if (!$weight['name']) continue;
            if ($weight['name'] == $defaultAns) return $weight['value'];
        }
    }
    return false;
}
// predictionFor(63, 1);
// echo '<br><pre>'. print_r(getEventIDs(), true) .'</pre>';