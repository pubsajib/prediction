<?php 
$names = array_keys(PredictionCron::config());
$names[] = 'summery';
echo '<div class="wrap">';
    echo '<h1>'. $heading .' CRON</h1>';
    echo '<div class="msgWrapper"></div>';
    if ($names) {
        echo '<div class="half first">';
            echo '<table class="cronTable" border="1" style="border-collapse: collapse;width: 100%;">';
                echo '<thead> <tr> <th>Name</th> <th>Action</th> </tr> </thead>';
                echo '<tbody>';
                    foreach ($names as $name) {
                        $important = 'summery' == $name ? ' style="border:2px solid red;"' : '';
                        echo '<tr id="'. $name .'"'. $important .'>';
                            echo '<td style="padding: 0 5px;">'. strtoupper(str_replace('_', ' ', $name)) .'</td> ';
                            echo '<td style="text-align: center; width: 100px;padding: 5px 0;"><button class="button button-primary cronBtn" cron="'. $name .'" type="button">Run</button></td>';
                        echo '</tr>';
                    }
                echo '</tbody>';
            echo '</table>';
        echo '</div>';
        echo '<div class="half last">';
            echo '<form class="tournamentList" method="post">';
                echo '<h3 class="m-0">Select working tournaments</h3><br>';
                foreach ($names as $name) {
                    if (in_array($name, ['all','summery'])) continue;
                    $disabled = in_array($name, (array) get_option('predictor_cron_options')) ? 'checked' : '';
                    echo '<div class="inputItem"><label><input type="checkbox" name="tournament[]" value="'. $name .'" class="tournament" '.$disabled.'> '. strtoupper(str_replace('_', ' ', $name)) .' </label></div>';
                }
                echo '<br><button class="button button-primary tournamentListBtn" type="submit">Save</button>';
            echo '</form>';
        echo '</div>';

    } else echo '<h4 style="color: red;">Not found</h4>';
echo '<div class="clearfix"></div>';
echo '</div>';

$type = 'all';
// $test = PredictionCron::allRankingCronFor($type);
// help($test);
// CREATING TABLES
// echo '<hr>';
$type = 'all'; PredictionCron::deleteRatingTableFor($type); PredictionCron::createRatingTableFor($type); help(PredictionCron::rankingCronFor($type));

// TESTING
