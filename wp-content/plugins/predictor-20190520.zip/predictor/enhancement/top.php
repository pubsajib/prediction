<?php 
// [top number=12]
class top {
	public static function render($attr) {
		$attr = shortcode_atts(['number' => 3, 'class' => 'eventSupperters'], $attr, 'top');
		return self::content($attr);
	}
	static function content($attr) {
		$data = '';
		$ranks = Ranks::all();
		if ($ranks) {
		    $profilePage = esc_url( site_url('predictor/'));
		    $all = $matches = $tosses = $tournaments = $t_20 = $odi = $ipl = $t20_toss = $odi_toss = $ipl_toss = [];
		    foreach($ranks as $user) {
		        $user = (array) $user;
		        // Ovarall
		        $all[$user['all_rank']] = $user; ksort($all);
		        $matches[$user['match_rank']] = $user; ksort($matches);
		        $tosses[$user['toss_rank']] = $user; ksort($tosses);
		        // Matches
		        $t_20[$user['t_20_rank']] = $user; ksort($t_20);
		        $odi[$user['odi_rank']] = $user; ksort($odi);
		        $test[$user['test_rank']] = $user; ksort($test);
		        $ipl[$user['ipl_rank']] = $user; ksort($ipl);
		        // Tosses
		        // $t20_toss[$user['t20_toss_rank']] = $user; ksort($t20_toss);
		        // $odi_toss[$user['odi_toss_rank']] = $user; ksort($odi_toss);
		        // $test_toss[$user['test_toss_rank']] = $user; ksort($test_toss);
		        // $ipl_toss[$user['ipl_toss_rank']] = $user; ksort($ipl_toss);
		    }
			$data .= '<div class="tabs tabs_default parent-ranking" id="RankAll">';
				$data .= '<ul class="horizontal rank">';
					$data .= '<li class="proli rank"><a href="#match">Match</a></li>';
					$data .= '<li class="proli rank"><a href="#toss">Toss</a></li>';
					$data .= '<li class="proli rank"><a href="#ipl">IPL</a></li>';
				$data .= '</ul>';
				// ================================== MATCH ===================================== //
				$data .= '<div id="match">';
		            $data .= self::slider($matches, $profilePage, $attr);
				$data .= '</div>';
				// ================================== TOSS ====================================== //
				$data .= '<div id="toss">';
					$data .= self::slider($tosses, $profilePage, $attr);
				$data .= '</div>';
				// ================================== IPL ======================================= //
				$data .= '<div id="ipl">'; $data .= self::slider($ipl, $profilePage, $attr); $data .= '</div>';
			$data .= '</div>';
		}
		return $data;
	}
	static function slider($supporters, $profilePage='', $attr) {
        $data = '';
        $counter = 0;
        if ($supporters) {
            $data .= '<div class="owl-carousel owl-theme '. $attr['class'] .'">';
                foreach ($supporters as $supporter) {
                    if ($counter >= $attr['number']) break;
                    $profileLink = $profilePage.'?p='. $supporter['login'];
                    $data .='<div class="item">';
                        $data .='<p><a href="'. $profileLink .'" target="_blank"><img style="border-radius:50%" src="'. $supporter['avatar'] .'"></a></p>';
                        $data .='<p style="text-align:center;">'. $supporter['name'] .'</p>';
                    $data .='</div>';
                    $counter++;
                }
            $data .= '</div>';
        }
        return $data;
    }
 }
add_shortcode('top', ['top', 'render']);