RATE TABLE

user rank (all) 	-> rank -> win -> lose -> accuracy -> eligiblity -> lifetimeEvents -> participated Events -> participation Rate -> minParticipationRate -> minParticipationEvent ->
user rank (match) 	-> rank -> win -> lose -> accuracy -> eligiblity -> lifetimeEvents -> participated Events -> participation Rate -> minParticipationRate -> minParticipationEvent ->
user rank (toss) 	-> rank -> win -> lose -> accuracy -> eligiblity -> lifetimeEvents -> participated Events -> participation Rate -> minParticipationRate -> minParticipationEvent ->
user rank (league) 	-> rank -> win -> lose -> accuracy -> eligiblity -> lifetimeEvents -> participated Events -> participation Rate -> minParticipationRate -> minParticipationEvent ->


CALENDAR
Ajax call



HEADER NOTIFICATION (Featured events)
TOP 10 PREDICTORS (all, toss, match, league)
TOP 3 PREDICTORS (league in post excerpt)
PCP -> user rank(all, toss, match), accuricy(all, toss, match)