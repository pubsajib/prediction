<?php
/* Template Name: Future Event */
get_header();
?>
<?php echo calendarEvents(''); ?>
<?php
get_footer();